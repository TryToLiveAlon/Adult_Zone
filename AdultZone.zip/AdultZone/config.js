module.exports = {
    token: '8084456321:AAGa0srHRdV_Wkci-GSkMhsBvu0pUEXNk8g',
    mongoURI: 'mongodb+srv://y45uaqull3fp:y45uaqull3fp@cluster0.2mlmp.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0',
    freeChannelID: '-1002422757094',   // Channel ID for free users
    premiumChannelID: '-1002406050801', // Channel ID for premium users
    adminID:"6140468904",
 
  mongoVideoURI:"mongodb+srv://Hacksrvkyt:Hacksrvkyt@cluster0.ag7ba.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
};
